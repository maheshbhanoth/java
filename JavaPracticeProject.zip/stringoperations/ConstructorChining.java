package stringoperations;

public class ConstructorChining {
public ConstructorChining() {
	this(100,200);
	System.out.println("default add constructor");
}
public ConstructorChining(int i,int j)
{
	this(223.5,30);
	System.out.println("result of i+j is:"+(i+j));
}
public ConstructorChining(double d,int i) {
	System.out.println("add if d+i is:"+(d+i));
}
public static void main(String[] args)
{
	ConstructorChining c1=new ConstructorChining();
}
}
