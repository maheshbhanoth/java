package stringoperations;

public class ConversionOfString1 {
	
	public static void main(String[] args)
    {
        // Creating objects of StringBuffer class
        StringBuffer sbr = new StringBuffer("java");
        StringBuilder sbdr = new StringBuilder("Hello");
 
        
        String str = sbr.toString();
 
        // Printing the above string
        System.out.println(
            "StringBuffer object to String : ");
        System.out.println(str);
 
        // Converting StringBuilder object to String
        String str1 = sbdr.toString();
 
        // Printing the above string
        System.out.println(
            "StringBuilder object to String : ");
        System.out.println(str1);
 
       
        sbr.append("ForProject");
 
        // Printing the above two strings on console
        System.out.println(sbr);
        System.out.println(str);
    }

}
