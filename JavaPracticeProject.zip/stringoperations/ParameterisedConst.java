package stringoperations;

public class ParameterisedConst {
	String name;
	int age;
	public ParameterisedConst(String sname,int sage)
	{
		name=sname;
		age=sage;
	}
	public static void main(String[] args) {
		ParameterisedConst c=new ParameterisedConst("john",22);
		System.out.println(c.name+" "+c.age);
		
		ParameterisedConst c1=new ParameterisedConst("rohan",21);
		System.out.println(c1.name+" "+c1.age);
		
		ParameterisedConst c2=new ParameterisedConst("rahul",20);
		System.out.println(c2.name+" "+c2.age);
		
	}

}
