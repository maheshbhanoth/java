package stringoperations;


public  class MethodCalling {
	
	//static method calling
	
		public static void values() {
		int i=10;
		{
			System.out.println("\ninteger value is: "+i);
		}
		}
		//user defined static method
		 static void showMethod(){
			 
		System.out.println("\nuser defined static method");
		}
		 
		 void meth()
		 {
			 System.out.println("\nnon static method calling");
		 }
		
		
			  public static void main(String[] args) {
			    
			    showMethod();
			    values();
			    MethodCalling m=new MethodCalling();
			    m.meth();
			    
	    
	}}

	   