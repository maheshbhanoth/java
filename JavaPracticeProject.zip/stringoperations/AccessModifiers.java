package stringoperations;

public class AccessModifiers {
	
	
	public static void values()
	{
		System.out.println("access modifiers in java");
	}
    private static void display() {	
     int a=10;
      System.out.println("the value is"+a);
}
    static void var() {
	int b=20;
	System.out.println("the value is"+b);
}
protected static void dis() {
	double d=100;
	System.out.println("protected value is"+d);
	

}
public static void main(String[] args) {
	display();
	values();
	var();
    dis();
	
	
}
}
