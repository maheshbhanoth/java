package stringoperations;

public class StringPractice {
	public static void main(String[] args) {
		String String_var1="string function programs";
		String String_var2="string function";
		
		//comenly used string functions
		System.out.println("String operations are:");
		
		//getting character at specific position
		System.out.println(String_var1.charAt(4));
		
		//get unicode operator at specific index
		System.out.println(String_var1.codePointAt(7));
		
		//get unicode operator at before specific index
		System.out.println(String_var1.codePointBefore(3));
		
		//no. of unicode char between the specific word
		System.out.println(String_var1.codePointCount(0,8));
		
		//compare two strings lexicographically i.e based on unicode value
		System.out.println("\n String comparission fuction:");
		
		System.out.println(String_var1.compareTo(String_var2));
		
		//compare two strings lexicographically ignoring the case
		System.out.println(String_var1.compareToIgnoreCase(String_var2));
		
		//concat operation
		System.out.println(String_var1.concat(String_var2));
		
		//check whether string contains another String
				System.out.println(String_var1.contains(String_var2));
				
				//check whether string ends with specific char
				System.out.println(String_var1.endsWith("gram"));
				
				//compare and returns true if the strings are equal
				System.out.println(String_var1.equals(String_var2));
				
				//compare and returns true by ignoring case
				System.out.println(String_var1.equalsIgnoreCase(String_var2));
				
				//compare and returns true if the strings are equal
				System.out.println(String_var1.equals(String_var2));
				
				//hashcode for a string computed like this
				System.out.println(String_var1.hashCode());
				
				//get the position of first occurance of specific char
				System.out.println(String_var1.indexOf("program"));
				
				//varies if string are equals
				String String_var3="Demo";
				System.out.println(String_var3.isEmpty());
				
				String_var3="function program function";
				System.out.println("/nlast occurance position");
				System.out.println(String_var3);
				
				//gets string length
				System.out.println(String_var1.length());
				
				//search string with specific value and replaces with it
				System.out.println(String_var3.replace("function","java"));
				System.out.println(String_var3);
				
				//string starts with
				System.out.println(String_var1.startsWith("string"));
				
				//converts strings to lower case 
				String_var1="HELLO WORLD";
				System.out.println(String_var1.toLowerCase());
				
				//converts  string to upper case
				System.out.println(String_var1.toUpperCase());
				
				//trims space before and all the string
				String String_var4="     Hello world";
				System.out.println(String_var4);
				System.out.println(String_var4.trim());
				
	}


}
