package stringoperations;

public class Implicit {  
		   public static void main(String args[]) { 
			   
			   //------implicit type casting in java------
			   
		      byte b = 12;  
		      System.out.println("byte value : "+b);  
		      
		    //automatically converts the byte type to short type
		      
		      short s = b;  
		      System.out.println("short value : "+s); 
		      
		    //automatically converts the short type to integer type
		      
		      int i = s;  
		      System.out.println("int value : "+i); 
		      
		    //automatically converts the integer type to long type
		      long l = i;  
		      System.out.println("long value : "+l); 
		      
		    //automatically converts the long type to float type
		      
		      float f= l;  
		      System.out.println("float value : "+f); 
		    
		    //automatically converts float type to double type
		      
		      double d = f;  
		      System.out.println("double value : "+d);  
		   }  
		}  