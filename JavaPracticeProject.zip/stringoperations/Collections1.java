package stringoperations;


import java.io.*;
import java.util.*;
public class Collections1 {
	
	  
	
	      // Main Method
	    public static void main(String[] args)
	    {
	  
	        // Declaring the LinkedList
	        LinkedList<Integer> l0 = new LinkedList<Integer>();
	  
	        // Appending new elements at
	        
	        for (int i = 1; i <= 6; i++)
	            l0.add(i);
	  
	        // Printing elements
	        System.out.println(l0);
	  
	        
	        l0.remove(3);
	  
	        // Displaying the List
	        // after deletion
	        System.out.println(l0);
	  
	        // Printing elements one by one
	        for (int i = 0; i < l0.size(); i++)
	            System.out.print(l0.get(i) + "  ");
	        
	    }
	    

}
