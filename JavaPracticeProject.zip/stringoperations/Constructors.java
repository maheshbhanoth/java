package stringoperations;

public class Constructors {
String name;
int sid;
public  Constructors() {
name="John";
sid=10;
}
public static void main(String[] args) {
	Constructors c=new Constructors();
	System.out.println(c.name);
	Constructors c1=new Constructors();
	System.out.println(c1.sid);
}}
