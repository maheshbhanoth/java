package stringoperations;

public class ExplicitTypeCasting {
	public static void main(String[] args) {
		
		double d = 166.66; 
		
		float f=(float)d;
		  
		long l = (long)f;  
		
		int i = (int)l; 
		 
		short s=(short)i;
		
		
		//fractional part lost
		System.out.println("Before conversion: "+d);  
  
		System.out.println("After conversion into long type: "+f);  
		 
		System.out.println("After conversion into int type: "+l);
		
		System.out.println("After conversion into int type: "+i);
	
		System.out.println("After conversion into int type: "+s);
		
	}

}
