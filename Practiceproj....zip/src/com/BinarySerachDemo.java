package com;

public class BinarySerachDemo {

	public static void main(String[] args) {
		System.out.println("Binary Search Demo ");
		int arr[] = { 10, 20, 23, 30, 40, 50, 77 };

		int key = 40;

		int positionOfTheKey = binarySearch(arr, 0, arr.length - 1, key);

		if (positionOfTheKey != -1) {
			System.out.println(key + " was found in index position " + positionOfTheKey);
		} else {
			System.out.println(key + " was not found");
		}
	}

	static int binarySearch(int[] arr, int start, int end, int key) {

		int midIndex = (start + end) / 2;

		while (start <= end) {

			if (key == arr[midIndex])
				return midIndex;

			else if (key < arr[midIndex]) {
				end = midIndex - 1;
			} else {
				start = midIndex + 1;
			}

			midIndex = (start + end) / 2;

		}

		// if we are here, then the key was not found
		return -1;
	}

}