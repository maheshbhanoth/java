package com;

public class ExponentialSearchdemo {

	public static void main(String[] args) {
		System.out.println("Exponential Search Demo ");
		int arr[] = { 10, 20, 23, 30, 40, 50, 77 };

		int key = 77;

		int positionOfTheKey = expSearch(arr, arr.length - 1, key);

		if (positionOfTheKey != -1) {
			System.out.println(key + " was found in index position " + positionOfTheKey);
		} else {
			System.out.println(key + " was not found");
		}
	}

	private static int expSearch(int[] arr, int end, int key) {

		// Is the key found in the first index (0)
		if (arr[0] == key)
			return 0;
		
		int i=1;
		
		while( i< end && arr[i] <= key)
			i = i*2 ;
		
		return BinarySerachDemo.binarySearch(arr, i/2, Math.min(i, end), key);
		
	}

}