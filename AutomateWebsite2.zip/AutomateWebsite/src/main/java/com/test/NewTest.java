package com.test;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest {
	WebDriver driver;
	@BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\MAHESH\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://amazon.in");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.close();
	}
	
	@Test
	public void verifyTitle() {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		Assert.assertEquals(actualTitle, expectedTitle);
		if(actualTitle == expectedTitle) {
			System.out.println("Both the titles match");
		}
		else {
			System.out.println("The titles does not match with each other");
		}
		driver.quit();
	}
	
	@Test
	public void verifyLogo() {
		boolean flag = driver.findElement(By.xpath("//a[@id='nav-logo-sprites']")).isDisplayed();
		Assert.assertTrue(flag);
		System.out.print("If the Logo matches, prints as true else false: " +flag);
		driver.quit();
	}
//	Amazon Registration process using @Test annotation
	
	@Test
	public void verifyRegistration() throws InterruptedException {
	driver.get("https://www.amazon.in/ap/register?openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		driver.manage().window().maximize();

		Thread.sleep(2000);
		driver.findElement(By.id("ap_customer_name")).sendKeys("Mahesh");
		Thread.sleep(2000);
		driver.findElement(By.id("ap_phone_number")).sendKeys("9949134005");
		Thread.sleep(2000);
		driver.findElement(By.id("ap_email")).sendKeys("maheshbanoth762@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("ap_password")).sendKeys("Mahesh@143");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		Thread.sleep(5000);
		String at = driver.getTitle();
		System.out.println("Driver title: "+ at);
		String st= "Authentication required";
		
		if(at.equalsIgnoreCase(st))
		{
//			If the credentials entered are correct the right output is detected and printed as success else failed
			System.out.println("Registration successfully");
		}
		else
		{
			System.out.println("Could not register the user, kindly enter the valid data");
		}
		driver.quit();
	}
//	Amazon Login process using @Test annotation, to validate the user

	@Test
	public void verifyLogin() throws InterruptedException {
	driver.navigate().to("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3F_encoding%3DUTF8%26adgrpid%3D58507629306%26ext_vrnc%3Dhi%26gclid%3DCj0KCQjw166aBhDEARIsAMEyZh49BAHZr2MkQN6X1lta2wC9Vkrnp8lVGy1CHaA6zRQaAfgmKUzTmeUaAib9EALw_wcB%26hvadid%3D486388034337%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D9062011%26hvnetw%3Dg%26hvpone%3D%26hvpos%3D%26hvptwo%3D%26hvqmt%3De%26hvrand%3D17084038091954731564%26hvtargid%3Dkwd-28878962%26hydadcr%3D14456_2154379%26ref%3Dpd_sl_1cfjttkdmt_e%26tag%3Dgooghydrabk1-21%26ref_%3Dnav_newcust&prevRID=D0F2ABJZC2NSZKCWSC4V&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&pageId=inflex&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		driver.findElement(By.id("ap_email")).sendKeys("maheshbanoth762@gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		Thread.sleep(2000);
		Thread.sleep(2000);
		driver.findElement(By.id("ap_password")).sendKeys("Mahesh@143");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
		String lat = driver.getTitle();
		System.out.println("Driver title: "+ lat);
		String lst= "Amazon Sign In";
		if(lat.equalsIgnoreCase(lst))
		{
			System.out.println("Login successfully");
			Thread.sleep(5000);
		}
		else
		{
			System.out.println("Could not login as the user entered invalid credentials");
			Thread.sleep(5000);
		}
		driver.quit();
	}

	@Test
	public void verifyZCart() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Samsung Galaxy M14 5G (Smoky Teal, 6GB, 128GB Storage) | 50MP Triple Cam | 6000 mAh Battery | 5nm Octa-Core Processor | 12GB RAM with RAM Plus | Android 13 | Without Charger");
		Thread.sleep(2000);
		driver.findElement(By.id("nav-search-submit-button")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("p_89/Samsung")).click();
		Thread.sleep(3000);
		driver.findElement(By.partialLinkText("Samsung Galaxy M14 5G (Smoky Teal, 6GB, 128GB Storage) | 50MP Triple Cam | 6000 mAh Battery | 5nm Octa-Core Processor | 12GB RAM with RAM Plus | Android 13 | Without Charger")).click();
		Thread.sleep(5000);
		driver.quit();
		System.out.println("Driver is exited, process execution is successful");	
	}

	@AfterGroups
	public void tearDown() {
		driver.quit();	
	}
}
