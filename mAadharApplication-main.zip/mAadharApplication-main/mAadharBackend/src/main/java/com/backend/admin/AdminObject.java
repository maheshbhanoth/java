package com.backend.admin;

/**
 * Created by IntelliJ IDEA
 * User: Abhinav Bhardwaj
 * Date: 13/10/22
 * Time: 11:27
 */


public class AdminObject {
}
