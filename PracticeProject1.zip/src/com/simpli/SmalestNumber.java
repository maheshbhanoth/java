package com.simpli;

import java.util.Arrays;
import java.util.Collections;
 
public class SmalestNumber{
    
    public static int kthSmallest(Integer[] arr, int K)
    {
       
        Arrays.sort(arr);
 
        return arr[K - 1];
    }
  
    public static void main(String[] args)
    {
        Integer arr[] = new Integer[] { 12, 3, 5, 7, 19,25,73,65,2 };
        int K =4;
 
       
        System.out.print(" 4th Smallest element is "
                         + kthSmallest(arr, K));
    }
}