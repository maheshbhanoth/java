package DamondProblem;

public class Diamond implements Interface1, Interface2 {
	public void display()   
	{  
	Interface1.super.foo();  
	Interface2.super.foo();  
	}  
    public static void main(String []args) {
        new Diamond().foo();
    }
}
