package DamondProblem;

interface Interface2 {
    default public void foo() { System.out.println("Interface2's foo"); }
}


