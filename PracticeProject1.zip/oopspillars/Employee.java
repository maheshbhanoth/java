package oopspillars;

     class Employee {
	    String name="Rohan";
        int age=23;
	    int salary = 60000;
	}
	  
