package oopspillars;

public class Polymorphism {

	    static int Multiply(int a, int b)
	    {
	        return a * b;
	    }

	    static int Multiply(int a, int b, int c)
	    {
	 
	        // Return product
	        return a * b * c;
	    }
	    static int add(int b,int a)
	    {
	    	return b+a;
	    }
	    public static void main(String[] args)
	    {
	 
	    	System.out.println(Polymorphism.Multiply(2, 4));
	        System.out.println(Polymorphism.Multiply(2, 7, 3));
	        System.out.println(Polymorphism.add(28,73));
	    }
	}