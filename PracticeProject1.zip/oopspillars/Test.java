package oopspillars;

public class Test {

	    public static void main(String[] args)
	    {
	       Shape s1 = new Circle("Red", 4.6);
	        Shape s2 = new Rectangle("Yellow", 5, 7);
	 
	       System.out.println(s1.toString());
	        System.out.println(s2.toString());
	    }
	}


