package oopspillars;

public class Main {
	
	    public static void main(String args[])
	    {
	    	
	        Engineer E1 = new Engineer();
	        System.out.println("emp name:"+E1.name);
	        System.out.println("emp age:"+E1.age);
	        System.out.println("Salary : " + E1.salary
	                           + "\nBenefits : " + E1.benefits);
	        
	    }
	}

