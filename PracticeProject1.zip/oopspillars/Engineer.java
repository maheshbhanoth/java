package oopspillars;


	class Engineer extends Employee {
	    int benefits = 10000;
	}

