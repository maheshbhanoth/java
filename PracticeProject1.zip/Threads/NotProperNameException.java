package Threads;
import java.util.*;
class NotProperNameException extends RuntimeException {
	   NotProperNameException(String msg){
	      super(msg);
	   }
	}
	