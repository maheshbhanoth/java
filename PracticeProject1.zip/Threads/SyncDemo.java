package Threads;

class SyncDemo extends Sender
{ 
    public static void main(String args[]) 
    { 
    	System.out.println(".....Typing msg......");
    	
        Sender s = new Sender(); 
        ThreadedSend S1 = 
            new ThreadedSend( " Hello " , s ); 
        ThreadedSend S2 = 
            new ThreadedSend( " Hope your doing good " , s ); 
        S1.start(); 
        S2.start(); 
        Sender s3 = new Sender(); 
        ThreadedSend S4 = 
            new ThreadedSend( " i am okay " , s ); 
        ThreadedSend S5 = 
            new ThreadedSend( " Bye " , s ); 
        S4.start(); 
        S5.start(); 
        try
        { 
            S4.join(); 
            S5.join(); 
        } 
        catch(Exception e) 
        { 
            System.out.println("Interrupted"); 
        } 
    } 
} 
