
package Threads;
public class MyThread extends Thread
{
 	public void run()
 	{
 		System.out.println("My sample Thread");
  		System.out.println("concurrent thread started running..");
  		System.out.println("Ending my thread");
}
 	public static void main( String args[] )
 	{
 		
 		
  		MyThread mt = new  MyThread();
  		mt.start();
  		
  		  		
  	    }
 	}

