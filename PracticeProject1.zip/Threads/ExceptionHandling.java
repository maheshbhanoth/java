package Threads;
import java.io.*;

public class ExceptionHandling {

	
	    public static void main (String[] args) {
	      int a=150;
	      int b=0;
	        try{
	          System.out.println(a/b);
	        }
	      catch(ArithmeticException e){
	        e.printStackTrace();
	      }
	    }
	}

