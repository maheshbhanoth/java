package com.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizAppAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
