package com.admin.model;

public class QnArray {
	
	private long[] qnId= new long[5];

	public long[] getQnId() {
		return qnId;
	}

	public void setQnId(long[] qnId) {
		this.qnId = qnId;
	}
	
	

}
